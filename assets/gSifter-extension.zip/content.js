(function () {
  if (document.getElementById('gsifter-root')) return;

  if (window.location.href.includes('/appointment')) {
    window.location.href = 'https://calendar.google.com/calendar/u/0/r';
  }

  const styleTag = document.createElement('style');
  styleTag.id = 'gsifter-injected-styles';
  styleTag.textContent = `
    #gsifter-root {
      position: fixed;
      bottom: 24px;
      right: 24px;
      z-index: 999999;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    }

    #gsifter-trigger-btn {
      width: 56px;
      height: 56px;
      border-radius: 50%;
      border: none;
      background: transparent;
      cursor: pointer;
      padding: 0;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.25);
      display: flex;
      align-items: center;
      justify-content: center;
      transition: transform 0.2s ease, box-shadow 0.2s ease;
      position: relative;
    }

    #gsifter-trigger-btn:hover {
      transform: scale(1.06);
      box-shadow: 0 6px 16px rgba(0, 0, 0, 0.35);
    }

    .gs-badge-dot {
      position: absolute;
      top: 2px;
      right: 2px;
      width: 12px;
      height: 12px;
      background-color: #ea4335;
      border: 2px solid #ffffff;
      border-radius: 50%;
      display: none;
    }

    #gsifter-sidebar-container {
      position: fixed;
      top: 0;
      right: 0;
      width: 380px;
      height: 100vh;
      z-index: 999998;
      box-shadow: -4px 0 16px rgba(0, 0, 0, 0.15);
      transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
      background: #ffffff;
    }

    #gsifter-sidebar-container.gsifter-collapsed {
      transform: translateX(100%);
    }

    #gsifter-sidebar-container.gsifter-expanded {
      transform: translateX(0);
    }

    #gsifter-iframe {
      width: 100%;
      height: 100%;
      border: none;
    }

    #gsifter-action-toast {
      position: fixed;
      top: 16px;
      left: 40%;
      transform: translateX(-50%);
      background: #202124;
      color: #ffffff;
      padding: 10px 24px 10px 18px;
      border-radius: 24px;
      font-size: 13px;
      font-weight: 500;
      box-shadow: 0 4px 14px rgba(0,0,0,0.3);
      z-index: 1000000;
      transition: opacity 0.25s ease, transform 0.25s ease;
      pointer-events: none;
    }

    #gsifter-action-toast.gs-toast-hidden {
      opacity: 0;
      transform: translate(-50%, -10px);
    }
  `;
  document.head.appendChild(styleTag);

  const root = document.createElement('div');
  root.id = 'gsifter-root';

  const triggerBtn = document.createElement('button');
  triggerBtn.id = 'gsifter-trigger-btn';
  triggerBtn.title = 'Open gSifter Assistant';
  
  triggerBtn.innerHTML = `
    <svg viewBox="0 0 64 64" width="52" height="52" style="display:block; width:100%; height:100%;">
      <defs>
        <linearGradient id="gs-trigger-gradient" x1="0" y1="0" x2="64" y2="64" gradientUnits="userSpaceOnUse">
          <stop offset="0" stop-color="#1a73e8"/>
          <stop offset="1" stop-color="#12b588"/>
        </linearGradient>
      </defs>
      <circle fill="url(#gs-trigger-gradient)" cx="32" cy="32" r="32"/>
      <path fill="#ffffff" fill-opacity="0.3" d="M16 18.15C16 17.32 16.67 16.65 17.5 16.65H46.5C47.33 16.65 48 18.15 48 18.15C48 18.44 47.92 18.72 47.76 18.96L37 35.61V46.65C37 47.15 36.75 47.62 36.33 47.89L27.83 53.45C26.97 54.01 25.82 53.77 25.26 52.92C24.93 52.41 24.75 51.81 24.75 51.19V35.62L16.24 18.97C16.08 18.73 16 18.45 16 18.15Z"/>
      <text fill="#ffffff" font-family="Helvetica-Bold, Helvetica, Arial, sans-serif" font-size="28" font-weight="700" x="14.25" y="42.34">gS</text>
      <path fill="#ffd034" d="M48 9C48 12.31 50.69 15 54 15C50.69 15 48 17.69 48 21C48 17.69 45.31 15 42 15C45.31 15 48 12.31 48 9Z"/>
    </svg>
    <span class="gs-badge-dot" id="gsifter-unread-dot"></span>
  `;

  const iframeContainer = document.createElement('div');
  iframeContainer.id = 'gsifter-sidebar-container';

  // Collapse sidebar during create event screen; expand when returning after Save
  const isCreatingEvent = window.location.search.includes('action=TEMPLATE') || window.location.pathname.includes('/eventedit');
  const hasJustSaved = !!localStorage.getItem('gsifter_just_saved_id');

  if (isCreatingEvent) {
    iframeContainer.className = 'gsifter-collapsed';
  } else if (hasJustSaved) {
    iframeContainer.className = 'gsifter-expanded';
  } else {
    iframeContainer.className = 'gsifter-collapsed';
  }

  const iframe = document.createElement('iframe');
  iframe.id = 'gsifter-iframe';
  iframe.src = chrome.runtime.getURL('sidebar.html');

  iframeContainer.appendChild(iframe);
  root.appendChild(triggerBtn);
  document.body.appendChild(root);
  document.body.appendChild(iframeContainer);

  const dot = document.getElementById('gsifter-unread-dot');

  const actionToast = document.createElement('div');
  actionToast.id = 'gsifter-action-toast';
  actionToast.className = 'gs-toast-hidden';
  document.body.appendChild(actionToast);

  function showActionToast(msg) {
    actionToast.textContent = msg;
    actionToast.classList.remove('gs-toast-hidden');
    setTimeout(() => {
      actionToast.classList.add('gs-toast-hidden');
    }, 3200);
  }

  function updateTriggerVisibility() {
    triggerBtn.style.display = document.visibilityState === 'visible' ? 'flex' : 'none';
  }

  document.addEventListener('visibilitychange', updateTriggerVisibility);
  updateTriggerVisibility();

  triggerBtn.addEventListener('click', () => {
    const isExpanded = iframeContainer.classList.contains('gsifter-expanded');
    
    if (!isExpanded) {
      iframeContainer.classList.add('gsifter-expanded');
      iframeContainer.classList.remove('gsifter-collapsed');
      if (dot) dot.style.display = 'none';
      iframe.contentWindow.postMessage({ action: 'SIDEBAR_OPENED' }, '*');
      sendCalendarsToSidebar();
    } else {
      iframeContainer.classList.remove('gsifter-expanded');
      iframeContainer.classList.add('gsifter-collapsed');
      iframe.contentWindow.postMessage({ action: 'SIDEBAR_CLOSED' }, '*');
    }
  });

  function scrapeMyCalendars() {
    const calendars = [];
    const seen = new Set();

    const blacklist = [
      'close banner', 'close', 'banner', 'dismiss', 'got it', 'hide',
      'my calendars', 'other calendars', 'options for', 'add other calendars',
      'settings and sharing', 'create', 'search for people', 'today', 'month',
      'week', 'day', 'year', 'schedule', 'main menu', 'google calendar'
    ];

    const navRegions = document.querySelectorAll('div[role="navigation"], div[role="region"]');
    navRegions.forEach(region => {
      const checkboxes = region.querySelectorAll('div[role="checkbox"][aria-label]');
      checkboxes.forEach(cb => {
        let label = cb.getAttribute('aria-label') || '';
        if (label.toLowerCase().startsWith('calendar:')) {
          label = label.replace(/^calendar:\s*/i, '').trim();
        }
        label = label.replace(/\s*\(primary\)$/i, '').replace(/\s*options$/i, '').trim();

        const isBlacklisted = blacklist.some(ign => label.toLowerCase().includes(ign));

        if (label && label.length > 1 && label.length < 45 && !seen.has(label.toLowerCase()) && !isBlacklisted) {
          seen.add(label.toLowerCase());
          calendars.push({ id: label, name: label });
        }
      });
    });

    return calendars;
  }

  function sendCalendarsToSidebar() {
    const cals = scrapeMyCalendars();
    iframe.contentWindow.postMessage({ action: 'MY_CALENDARS_RESPONSE', calendars: cals }, '*');
  }

  function formatISODateTime(dateStr, timeStr) {
    if (!dateStr) return '';
    const cleanDate = dateStr.replace(/-/g, '');
    let cleanTime = '090000';
    if (timeStr) {
      const cleanT = timeStr.trim().toLowerCase();
      let h = 9, m = 0;
      if (cleanT.includes('am') || cleanT.includes('pm')) {
        const isPm = cleanT.includes('pm');
        const num = cleanT.replace('am', '').replace('pm', '').trim();
        const parts = num.split(':');
        h = parseInt(parts[0], 10) || 9;
        m = parseInt(parts[1], 10) || 0;
        if (isPm && h < 12) h += 12;
        if (!isPm && h === 12) h = 0;
      } else {
        const parts = cleanT.split(':');
        h = parseInt(parts[0], 10) || 9;
        m = parseInt(parts[1], 10) || 0;
      }
      const hh = h < 10 ? `0${h}` : `${h}`;
      const mm = m < 10 ? `0${m}` : `${m}`;
      cleanTime = `${hh}${mm}00`;
    }
    return `${cleanDate}T${cleanTime}`;
  }

  function buildTemplateUrl(eventData) {
    const userPathMatch = window.location.pathname.match(/\/calendar\/u\/\d+/);
    const basePath = userPathMatch ? userPathMatch[0] : '/calendar/u/0';

    const startISO = formatISODateTime(eventData.startDate, eventData.startTime);
    const endISO = formatISODateTime(eventData.endDate || eventData.startDate, eventData.endTime || eventData.startTime);

    const queryParams = ['action=TEMPLATE'];
    if (eventData.title) queryParams.push(`text=${encodeURIComponent(eventData.title)}`);
    if (startISO && endISO) queryParams.push(`dates=${startISO}/${endISO}`);
    if (eventData.location) queryParams.push(`location=${encodeURIComponent(eventData.location)}`);
    if (eventData.notes) queryParams.push(`details=${encodeURIComponent(eventData.notes)}`);

    return `https://calendar.google.com${basePath}/render?${queryParams.join('&')}`;
  }

  function notifySuccess(eventId) {
    if (!eventId) return;

    // Automatically reopen the sidebar after event is saved in Calendar
    iframeContainer.classList.add('gsifter-expanded');
    iframeContainer.classList.remove('gsifter-collapsed');

    iframe.contentWindow.postMessage({
      action: 'EVENT_ADDED_SUCCESS',
      eventId: eventId
    }, '*');
  }

  function checkJustSaved() {
    const justSavedId = localStorage.getItem('gsifter_just_saved_id');
    if (justSavedId) {
      localStorage.removeItem('gsifter_just_saved_id');
      notifySuccess(justSavedId);
    }
  }

  document.addEventListener('click', (e) => {
    const btn = e.target.closest('button, div[role="button"]');
    if (!btn) return;

    const txt = (btn.textContent || '').trim().toLowerCase();
    const aria = (btn.getAttribute('aria-label') || '').trim().toLowerCase();

    if (txt === 'save' || aria === 'save') {
      const pendingId = localStorage.getItem('gsifter_pending_event_id');
      if (pendingId) {
        localStorage.setItem('gsifter_just_saved_id', pendingId);
        localStorage.removeItem('gsifter_pending_event_id');
        setTimeout(checkJustSaved, 300);
      }
    }
  }, true);

  document.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 's') {
      const pendingId = localStorage.getItem('gsifter_pending_event_id');
      if (pendingId) {
        localStorage.setItem('gsifter_just_saved_id', pendingId);
        localStorage.removeItem('gsifter_pending_event_id');
        setTimeout(checkJustSaved, 300);
      }
    }
  }, true);

  window.addEventListener('focus', checkJustSaved);
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') checkJustSaved();
  });

  async function createSingularEventDirectly(eventData) {
    showActionToast(`Opening event creation for "${eventData.title || 'Event'}"...`);

    // Hide/collapse sidebar during creation screen
    iframeContainer.classList.remove('gsifter-expanded');
    iframeContainer.classList.add('gsifter-collapsed');

    localStorage.setItem('gsifter_pending_event_id', eventData.id);

    const templateUrl = buildTemplateUrl(eventData);
    window.location.href = templateUrl;
  }

  window.addEventListener('message', async (event) => {
    if (!event.data) return;

    if (event.data.action === 'GET_MY_CALENDARS') {
      sendCalendarsToSidebar();
    } else if (event.data.action === 'CLOSE_GSIFTER_SIDEBAR') {
      iframeContainer.classList.remove('gsifter-expanded');
      iframeContainer.classList.add('gsifter-collapsed');
      iframe.contentWindow.postMessage({ action: 'SIDEBAR_CLOSED' }, '*');
    } else if (event.data.action === 'SHOW_UNREAD_DOT') {
      const isExpanded = iframeContainer.classList.contains('gsifter-expanded');
      if (!isExpanded && dot) dot.style.display = 'block';
    } else if (event.data.action === 'HIDE_UNREAD_DOT') {
      if (dot) dot.style.display = 'none';
    } else if (event.data.action === 'DIRECT_ADD_EVENT') {
      await createSingularEventDirectly(event.data.eventData);
    }
  });

  checkJustSaved();
})();