(function () {
  function findToken() {
    try {
      if (window.WIZ_global_data) {
        if (window.WIZ_global_data.SNlM0e) return window.WIZ_global_data.SNlM0e;
        if (window.WIZ_global_data.at) return window.WIZ_global_data.at;
      }
      if (window.IJ_values && Array.isArray(window.IJ_values)) {
        for (let i = 0; i < window.IJ_values.length; i++) {
          if (typeof window.IJ_values[i] === 'string' && window.IJ_values[i].length > 10) {
            return window.IJ_values[i];
          }
        }
      }
      if (window.AF_initDataChunkQueue && Array.isArray(window.AF_initDataChunkQueue)) {
        for (let j = 0; j < window.AF_initDataChunkQueue.length; j++) {
          const item = window.AF_initDataChunkQueue[j];
          if (item && typeof item === 'object') {
            if (item.SNlM0e) return item.SNlM0e;
            if (item.at) return item.at;
          }
        }
      }
    } catch (e) {}
    return null;
  }

  function syncToken() {
    try {
      const tok = findToken();
      if (tok && document.documentElement) {
        document.documentElement.setAttribute('data-gsifter-token', tok);
      }
    } catch (e) {}
  }

  syncToken();
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', syncToken);
  }
  setInterval(syncToken, 200);

  window.addEventListener('GSIFTER_FETCH_TOKEN_REQUEST', () => {
    syncToken();
    const tok = findToken();
    window.dispatchEvent(new CustomEvent('GSIFTER_FETCH_TOKEN_RESPONSE', { detail: { token: tok } }));
  });
})();