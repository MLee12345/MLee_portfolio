// background.js - Service Worker for gSifter Extension

// Extension Installation
chrome.runtime.onInstalled.addListener(() => {
  console.log('gSifter extension initialized.');
});

// Central Message Router
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || !message.action) {
    return false;
  }

  switch (message.action) {
    case 'OAUTH_AUTHORIZE':
      handleOAuthAuthorize(message.email, sendResponse);
      return true; // Return true to keep message channel open for async response

    case 'GET_MY_CALENDARS':
      handleGetCalendars(sendResponse);
      return true;

    case 'DIRECT_ADD_EVENT':
      handleAddEvent(message.eventData, sendResponse);
      return true;

    default:
      return false;
  }
});

/**
 * Handles OAuth Authentication
 */
function handleOAuthAuthorize(email, sendResponse) {
  chrome.identity.getAuthToken({ interactive: true }, (token) => {
    if (chrome.runtime.lastError) {
      console.warn('OAuth Auth Token Notice:', chrome.runtime.lastError.message);
      sendResponse({ token: null, isLocalFallback: true, error: chrome.runtime.lastError.message });
      return;
    }

    if (token) {
      sendResponse({ token: token, isLocalFallback: false });
    } else {
      sendResponse({ token: null, isLocalFallback: true });
    }
  });
}

/**
 * Fetches connected Google Calendars list
 */
function handleGetCalendars(sendResponse) {
  chrome.identity.getAuthToken({ interactive: false }, (token) => {
    if (chrome.runtime.lastError || !token) {
      sendResponse({
        calendars: [
          { id: 'primary', name: 'Personal Calendar' }
        ]
      });
      return;
    }

    fetch('https://www.googleapis.com/calendar/v3/users/me/calendarList', {
      headers: { Authorization: `Bearer ${token}` }
    })
      .then((res) => res.json())
      .then((data) => {
        if (data.items && Array.isArray(data.items)) {
          const calendars = data.items.map((cal) => ({
            id: cal.id,
            name: cal.summary || 'Calendar'
          }));
          sendResponse({ calendars });
        } else {
          sendResponse({ calendars: [{ id: 'primary', name: 'Personal Calendar' }] });
        }
      })
      .catch((err) => {
        console.error('Fetch calendars failed:', err);
        sendResponse({ calendars: [{ id: 'primary', name: 'Personal Calendar' }] });
      });
  });
}

/**
 * Adds an event to Google Calendar API
 */
function handleAddEvent(eventData, sendResponse) {
  chrome.identity.getAuthToken({ interactive: true }, (token) => {
    if (chrome.runtime.lastError || !token) {
      sendResponse({ success: false, error: 'Authentication failed' });
      return;
    }

    const calendarId = eventData.targetCalendar || 'primary';
    
    // Construct ISO Date Strings
    const startIso = parseIsoString(eventData.startDate, eventData.startTime);
    const endIso = parseIsoString(eventData.endDate || eventData.startDate, eventData.endTime);

    const eventPayload = {
      summary: eventData.title,
      location: eventData.location || '',
      description: eventData.notes || '',
      start: { dateTime: startIso },
      end: { dateTime: endIso }
    };

    fetch(`https://www.googleapis.com/calendar/v3/calendars/${encodeURIComponent(calendarId)}/events`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(eventPayload)
    })
      .then((res) => res.json())
      .then((data) => {
        if (data.id) {
          sendResponse({ success: true, eventId: eventData.id, googleEventId: data.id });
        } else {
          sendResponse({ success: false, error: data.error?.message || 'Failed to add event' });
        }
      })
      .catch((err) => {
        console.error('Add event API error:', err);
        sendResponse({ success: false, error: err.message });
      });
  });
}

/**
 * Helper to construct ISO 8601 Date String
 */
function parseIsoString(dateStr, timeStr) {
  if (!dateStr) return new Date().toISOString();
  
  let h = 9, m = 0;
  if (timeStr) {
    const clean = timeStr.trim().toLowerCase();
    const isPm = clean.includes('pm');
    const isAm = clean.includes('am');
    const digits = clean.replace(/(am|pm)/g, '').trim().split(':');
    
    h = parseInt(digits[0], 10) || 9;
    m = parseInt(digits[1], 10) || 0;

    if (isPm && h < 12) h += 12;
    if (isAm && h === 12) h = 0;
  }

  const dateObj = new Date(`${dateStr}T00:00:00`);
  dateObj.setHours(h, m, 0, 0);
  return dateObj.toISOString();
}